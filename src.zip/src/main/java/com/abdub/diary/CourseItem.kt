package com.maseria.diary

data class CourseItem(
    val courseCode: String,
    val courseTitle: String,
    val contactHours: String,
    val days: String,
    val time: String
)