package com.maseria.diary

data class NewsItem (
    val title: String,
    val keyword : String,
    val highlights: String
)