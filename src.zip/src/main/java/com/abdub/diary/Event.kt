package com.maseria.diary

data class Event(
    val type: String,
    val time: String,
    val day: String,
    val note: String
)